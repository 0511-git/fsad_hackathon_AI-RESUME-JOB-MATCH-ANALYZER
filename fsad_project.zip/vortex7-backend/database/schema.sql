-- ============================================
-- Vortex-7 Database Schema
-- MySQL Database Setup Script
-- ============================================

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS vortex7_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE vortex7_db;

-- ============================================
-- Sales Table
-- Stores all sales transaction records
-- ============================================
CREATE TABLE IF NOT EXISTS sales (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sale_id VARCHAR(20) NOT NULL UNIQUE,
    product_name VARCHAR(200) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(15, 2) NOT NULL CHECK (unit_price >= 0),
    total DECIMAL(15, 2) NOT NULL CHECK (total >= 0),
    sale_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_sale_date (sale_date),
    INDEX idx_product_name (product_name),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Sample Data Insertion
-- Initial data for testing and demonstration
-- ============================================

INSERT INTO sales (sale_id, product_name, quantity, unit_price, total, sale_date) VALUES
('SL-001', 'Enterprise License', 5, 2500.00, 12500.00, '2026-04-01'),
('SL-002', 'Professional Plan', 12, 99.00, 1188.00, '2026-04-01'),
('SL-003', 'Consulting Services', 40, 150.00, 6000.00, '2026-03-31'),
('SL-004', 'Support Package', 8, 500.00, 4000.00, '2026-03-30'),
('SL-005', 'Custom Integration', 2, 3500.00, 7000.00, '2026-03-29'),
('SL-006', 'Cloud Storage Add-on', 25, 49.99, 1249.75, '2026-03-28'),
('SL-007', 'API Access License', 10, 199.00, 1990.00, '2026-03-27'),
('SL-008', 'Training Session', 6, 800.00, 4800.00, '2026-03-26');

-- ============================================
-- Useful Queries for Reference
-- ============================================

-- Get total revenue
-- SELECT SUM(total) FROM sales;

-- Get transaction count
-- SELECT COUNT(*) FROM sales;

-- Get average order value
-- SELECT AVG(total) FROM sales;

-- Get revenue by date for charts
-- SELECT sale_date, SUM(total), COUNT(*) FROM sales GROUP BY sale_date ORDER BY sale_date;

-- Get revenue by product
-- SELECT product_name, SUM(total), SUM(quantity) FROM sales GROUP BY product_name ORDER BY SUM(total) DESC;

-- Get recent sales (last 7 days)
-- SELECT * FROM sales WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) ORDER BY sale_date DESC;
