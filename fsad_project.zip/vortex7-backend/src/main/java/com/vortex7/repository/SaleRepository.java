package com.vortex7.repository;

import com.vortex7.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * SaleRepository - Data access layer for Sale entity
 * Extends JpaRepository for CRUD operations and custom queries
 */
@Repository
public interface SaleRepository extends JpaRepository<Sale, Long> {

    /**
     * Find sale by unique sale ID
     */
    Optional<Sale> findBySaleId(String saleId);

    /**
     * Check if sale ID exists
     */
    boolean existsBySaleId(String saleId);

    /**
     * Find all sales ordered by sale date descending (most recent first)
     */
    List<Sale> findAllByOrderBySaleDateDesc();

    /**
     * Find sales by product name (case-insensitive search)
     */
    List<Sale> findByProductNameContainingIgnoreCase(String productName);

    /**
     * Find sales within a date range
     */
    List<Sale> findBySaleDateBetweenOrderBySaleDateDesc(LocalDate startDate, LocalDate endDate);

    /**
     * Get total revenue for a date range
     */
    @Query("SELECT COALESCE(SUM(s.total), 0) FROM Sale s WHERE s.saleDate BETWEEN :startDate AND :endDate")
    BigDecimal getTotalRevenueBetweenDates(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    /**
     * Get total revenue across all sales
     */
    @Query("SELECT COALESCE(SUM(s.total), 0) FROM Sale s")
    BigDecimal getTotalRevenue();

    /**
     * Get total transaction count
     */
    @Query("SELECT COUNT(s) FROM Sale s")
    Long getTransactionCount();

    /**
     * Get average order value
     */
    @Query("SELECT COALESCE(AVG(s.total), 0) FROM Sale s")
    BigDecimal getAverageOrderValue();

    /**
     * Get revenue grouped by date for chart data
     */
    @Query("SELECT s.saleDate, SUM(s.total), COUNT(s) FROM Sale s GROUP BY s.saleDate ORDER BY s.saleDate")
    List<Object[]> getRevenueByDate();

    /**
     * Get revenue grouped by product name
     */
    @Query("SELECT s.productName, SUM(s.total), SUM(s.quantity) FROM Sale s GROUP BY s.productName ORDER BY SUM(s.total) DESC")
    List<Object[]> getRevenueByProduct();

    /**
     * Get top N selling products by revenue
     */
    @Query("SELECT s.productName, SUM(s.total) as revenue FROM Sale s GROUP BY s.productName ORDER BY revenue DESC")
    List<Object[]> getTopProductsByRevenue(org.springframework.data.domain.Pageable pageable);

    /**
     * Get sales for the last N days
     */
    @Query("SELECT s FROM Sale s WHERE s.saleDate >= :startDate ORDER BY s.saleDate DESC")
    List<Sale> findRecentSales(@Param("startDate") LocalDate startDate);

    /**
     * Count sales in a date range
     */
    @Query("SELECT COUNT(s) FROM Sale s WHERE s.saleDate BETWEEN :startDate AND :endDate")
    Long countSalesBetweenDates(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}
