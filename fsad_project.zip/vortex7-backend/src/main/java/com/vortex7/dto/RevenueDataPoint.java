package com.vortex7.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * RevenueDataPoint DTO - Single data point for revenue charts
 * Used for chart data visualization
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RevenueDataPoint {

    private LocalDate date;
    private String label;
    private BigDecimal revenue;
    private Integer transactionCount;
}
