package com.vortex7.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * LoginResponse DTO - Data Transfer Object for login responses
 * Contains authentication result and user information
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponse {

    private boolean success;
    private String message;
    private String token;
    private String email;
    private String userName;
    private LocalDateTime timestamp;
    private String nextStep; // For multi-step authentication (e.g., "OTP_REQUIRED")
}
