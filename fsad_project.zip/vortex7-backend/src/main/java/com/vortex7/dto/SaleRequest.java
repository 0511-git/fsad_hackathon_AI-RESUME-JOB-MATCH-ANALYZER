package com.vortex7.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * SaleRequest DTO - Data Transfer Object for creating/updating sales
 * Used for request validation and data transfer
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SaleRequest {

    @NotBlank(message = "Product name is required")
    @Size(max = 200, message = "Product name must not exceed 200 characters")
    private String productName;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Quantity must be at least 1")
    @Max(value = 999999, message = "Quantity must not exceed 999999")
    private Integer quantity;

    @NotNull(message = "Unit price is required")
    @DecimalMin(value = "0.00", inclusive = true, message = "Unit price must be positive")
    @DecimalMax(value = "999999999.99", message = "Unit price exceeds maximum allowed")
    @Digits(integer = 9, fraction = 2, message = "Unit price must have at most 2 decimal places")
    private BigDecimal unitPrice;

    @NotNull(message = "Sale date is required")
    private LocalDate saleDate;
}
