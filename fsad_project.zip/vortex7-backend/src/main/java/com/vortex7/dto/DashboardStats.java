package com.vortex7.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * DashboardStats DTO - Contains dashboard statistics
 * Used for the overview cards on the dashboard
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStats {

    private BigDecimal totalRevenue;
    private Long transactionCount;
    private BigDecimal averageOrderValue;
    private BigDecimal revenueGrowthPercentage;
    private BigDecimal transactionGrowthPercentage;
    private BigDecimal aovGrowthPercentage;
}
