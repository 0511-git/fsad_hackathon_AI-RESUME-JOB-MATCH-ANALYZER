package com.vortex7.controller;

import com.vortex7.dto.*;
import com.vortex7.service.SaleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * SaleController - REST API Controller for sales operations
 * Provides endpoints for CRUD operations and analytics
 */
@Slf4j
@RestController
@RequestMapping("/api/sales")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class SaleController {

    private final SaleService saleService;

    /**
     * Create a new sale record
     * POST /api/sales
     */
    @PostMapping
    public ResponseEntity<ApiResponse<SaleResponse>> createSale(@Valid @RequestBody SaleRequest request) {
        log.info("POST /api/sales - Creating new sale for product: {}", request.getProductName());
        
        SaleResponse sale = saleService.createSale(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(sale, "Sale record created successfully"));
    }

    /**
     * Get all sales
     * GET /api/sales
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<SaleResponse>>> getAllSales() {
        log.info("GET /api/sales - Fetching all sales");
        
        List<SaleResponse> sales = saleService.getAllSales();
        return ResponseEntity.ok(ApiResponse.success(sales, "Sales retrieved successfully"));
    }

    /**
     * Get sale by ID
     * GET /api/sales/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<SaleResponse>> getSaleById(@PathVariable Long id) {
        log.info("GET /api/sales/{} - Fetching sale by ID", id);
        
        SaleResponse sale = saleService.getSaleById(id);
        return ResponseEntity.ok(ApiResponse.success(sale, "Sale retrieved successfully"));
    }

    /**
     * Update a sale
     * PUT /api/sales/{id}
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<SaleResponse>> updateSale(
            @PathVariable Long id,
            @Valid @RequestBody SaleRequest request) {
        log.info("PUT /api/sales/{} - Updating sale", id);
        
        SaleResponse sale = saleService.updateSale(id, request);
        return ResponseEntity.ok(ApiResponse.success(sale, "Sale updated successfully"));
    }

    /**
     * Delete a sale
     * DELETE /api/sales/{id}
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteSale(@PathVariable Long id) {
        log.info("DELETE /api/sales/{} - Deleting sale", id);
        
        saleService.deleteSale(id);
        return ResponseEntity.ok(ApiResponse.success("Sale deleted successfully"));
    }

    /**
     * Search sales by product name
     * GET /api/sales/search?productName={name}
     */
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<SaleResponse>>> searchSales(
            @RequestParam String productName) {
        log.info("GET /api/sales/search - Searching sales for product: {}", productName);
        
        List<SaleResponse> sales = saleService.searchSales(productName);
        return ResponseEntity.ok(ApiResponse.success(sales, "Search completed successfully"));
    }

    /**
     * Get dashboard statistics
     * GET /api/sales/stats/dashboard
     */
    @GetMapping("/stats/dashboard")
    public ResponseEntity<ApiResponse<DashboardStats>> getDashboardStats() {
        log.info("GET /api/sales/stats/dashboard - Fetching dashboard statistics");
        
        DashboardStats stats = saleService.getDashboardStats();
        return ResponseEntity.ok(ApiResponse.success(stats, "Dashboard statistics retrieved successfully"));
    }

    /**
     * Get revenue data points for chart
     * GET /api/sales/stats/revenue-chart
     */
    @GetMapping("/stats/revenue-chart")
    public ResponseEntity<ApiResponse<List<RevenueDataPoint>>> getRevenueChartData() {
        log.info("GET /api/sales/stats/revenue-chart - Fetching revenue chart data");
        
        List<RevenueDataPoint> dataPoints = saleService.getRevenueDataPoints();
        return ResponseEntity.ok(ApiResponse.success(dataPoints, "Revenue chart data retrieved successfully"));
    }

    /**
     * Get revenue by product for distribution chart
     * GET /api/sales/stats/by-product
     */
    @GetMapping("/stats/by-product")
    public ResponseEntity<ApiResponse<List<SaleService.ProductRevenueDto>>> getRevenueByProduct() {
        log.info("GET /api/sales/stats/by-product - Fetching revenue by product");
        
        List<SaleService.ProductRevenueDto> data = saleService.getRevenueByProduct();
        return ResponseEntity.ok(ApiResponse.success(data, "Revenue by product retrieved successfully"));
    }

    /**
     * Get top performing products
     * GET /api/sales/stats/top-products?limit={n}
     */
    @GetMapping("/stats/top-products")
    public ResponseEntity<ApiResponse<List<SaleService.ProductRevenueDto>>> getTopProducts(
            @RequestParam(defaultValue = "5") int limit) {
        log.info("GET /api/sales/stats/top-products - Fetching top {} products", limit);
        
        List<SaleService.ProductRevenueDto> products = saleService.getTopProducts(limit);
        return ResponseEntity.ok(ApiResponse.success(products, "Top products retrieved successfully"));
    }
}
