package com.vortex7.controller;

import com.vortex7.dto.ApiResponse;
import com.vortex7.dto.LoginRequest;
import com.vortex7.dto.LoginResponse;
import com.vortex7.service.AuthenticationService;
import com.vortex7.validation.EmailValidator.ValidationResult;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * AuthController - REST API Controller for authentication operations
 * Provides endpoints for login and email validation
 */
@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthenticationService authenticationService;

    /**
     * Login endpoint with strict Gmail validation
     * POST /api/auth/login
     */
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(
            @Valid @RequestBody LoginRequest request,
            HttpServletRequest httpRequest) {
        
        log.info("POST /api/auth/login - Login attempt from IP: {}", httpRequest.getRemoteAddr());
        
        // Process login with validation
        LoginResponse loginResponse = authenticationService.login(request);
        
        if (!loginResponse.isSuccess()) {
            // Return 400 Bad Request for validation failures
            ApiResponse<LoginResponse> response = ApiResponse.<LoginResponse>builder()
                    .success(false)
                    .message(loginResponse.getMessage())
                    .data(loginResponse)
                    .timestamp(LocalDateTime.now())
                    .path(httpRequest.getRequestURI())
                    .build();
            
            return ResponseEntity.badRequest().body(response);
        }
        
        // Return success response
        ApiResponse<LoginResponse> response = ApiResponse.<LoginResponse>builder()
                .success(true)
                .message("Login credentials validated successfully")
                .data(loginResponse)
                .timestamp(LocalDateTime.now())
                .path(httpRequest.getRequestURI())
                .build();
        
        return ResponseEntity.ok(response);
    }

    /**
     * Validate email endpoint (for frontend pre-validation)
     * GET /api/auth/validate-email?email={email}
     */
    @GetMapping("/validate-email")
    public ResponseEntity<ApiResponse<Map<String, Object>>> validateEmail(
            @RequestParam String email,
            HttpServletRequest httpRequest) {
        
        log.debug("GET /api/auth/validate-email - Validating email: {}", maskEmail(email));
        
        ValidationResult result = authenticationService.validateEmail(email);
        
        Map<String, Object> data = Map.of(
                "valid", result.valid(),
                "email", email
        );
        
        ApiResponse<Map<String, Object>> response = ApiResponse.<Map<String, Object>>builder()
                .success(result.valid())
                .message(result.valid() ? "Email is valid" : result.message())
                .data(data)
                .timestamp(LocalDateTime.now())
                .path(httpRequest.getRequestURI())
                .build();
        
        if (result.valid()) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * Check if email is Gmail (quick check endpoint)
     * GET /api/auth/is-gmail?email={email}
     */
    @GetMapping("/is-gmail")
    public ResponseEntity<ApiResponse<Map<String, Object>>> isGmail(
            @RequestParam String email,
            HttpServletRequest httpRequest) {
        
        boolean isValidGmail = authenticationService.isValidGmail(email);
        
        Map<String, Object> data = Map.of(
                "isGmail", isValidGmail,
                "email", email
        );
        
        ApiResponse<Map<String, Object>> response = ApiResponse.<Map<String, Object>>builder()
                .success(true)
                .message(isValidGmail ? "Valid Gmail address" : "Not a valid Gmail address")
                .data(data)
                .timestamp(LocalDateTime.now())
                .path(httpRequest.getRequestURI())
                .build();
        
        return ResponseEntity.ok(response);
    }

    /**
     * Mask email for logging
     */
    private String maskEmail(String email) {
        if (email == null || !email.contains("@")) {
            return "***";
        }
        String localPart = email.substring(0, email.indexOf('@'));
        String domain = email.substring(email.indexOf('@'));
        
        if (localPart.length() <= 2) {
            return "***" + domain;
        }
        
        return localPart.charAt(0) + "***" + domain;
    }
}
