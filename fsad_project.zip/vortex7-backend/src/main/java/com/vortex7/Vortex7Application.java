package com.vortex7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Vortex-7 Enterprise Revenue Analytics Backend Application
 * Spring Boot entry point
 */
@SpringBootApplication
public class Vortex7Application {

    public static void main(String[] args) {
        SpringApplication.run(Vortex7Application.class, args);
    }
}
