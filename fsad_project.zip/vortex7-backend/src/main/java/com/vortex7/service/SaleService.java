package com.vortex7.service;

import com.vortex7.dto.*;
import com.vortex7.entity.Sale;
import com.vortex7.repository.SaleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * SaleService - Business logic layer for sales operations
 * Handles CRUD operations, statistics calculation, and data transformation
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SaleService {

    private final SaleRepository saleRepository;

    /**
     * Generate unique sale ID (SL-XXX format)
     */
    private String generateSaleId() {
        long count = saleRepository.count() + 1;
        return String.format("SL-%03d", count);
    }

    /**
     * Convert Sale entity to SaleResponse DTO
     */
    private SaleResponse mapToResponse(Sale sale) {
        return SaleResponse.builder()
                .id(sale.getId())
                .saleId(sale.getSaleId())
                .productName(sale.getProductName())
                .quantity(sale.getQuantity())
                .unitPrice(sale.getUnitPrice())
                .total(sale.getTotal())
                .saleDate(sale.getSaleDate())
                .createdAt(sale.getCreatedAt())
                .updatedAt(sale.getUpdatedAt())
                .build();
    }

    /**
     * Create a new sale record
     */
    @Transactional
    public SaleResponse createSale(SaleRequest request) {
        log.info("Creating new sale for product: {}", request.getProductName());

        Sale sale = new Sale();
        sale.setSaleId(generateSaleId());
        sale.setProductName(request.getProductName());
        sale.setQuantity(request.getQuantity());
        sale.setUnitPrice(request.getUnitPrice());
        sale.setSaleDate(request.getSaleDate());
        sale.setTotal(request.getUnitPrice().multiply(BigDecimal.valueOf(request.getQuantity())));

        Sale savedSale = saleRepository.save(sale);
        log.info("Sale created with ID: {}", savedSale.getSaleId());

        return mapToResponse(savedSale);
    }

    /**
     * Get all sales ordered by date (most recent first)
     */
    @Transactional(readOnly = true)
    public List<SaleResponse> getAllSales() {
        return saleRepository.findAllByOrderBySaleDateDesc()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /**
     * Get sale by ID
     */
    @Transactional(readOnly = true)
    public SaleResponse getSaleById(Long id) {
        Sale sale = saleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sale not found with ID: " + id));
        return mapToResponse(sale);
    }

    /**
     * Get sale by sale ID
     */
    @Transactional(readOnly = true)
    public SaleResponse getSaleBySaleId(String saleId) {
        Sale sale = saleRepository.findBySaleId(saleId)
                .orElseThrow(() -> new RuntimeException("Sale not found with Sale ID: " + saleId));
        return mapToResponse(sale);
    }

    /**
     * Update an existing sale
     */
    @Transactional
    public SaleResponse updateSale(Long id, SaleRequest request) {
        log.info("Updating sale with ID: {}", id);

        Sale sale = saleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sale not found with ID: " + id));

        sale.setProductName(request.getProductName());
        sale.setQuantity(request.getQuantity());
        sale.setUnitPrice(request.getUnitPrice());
        sale.setSaleDate(request.getSaleDate());
        sale.setTotal(request.getUnitPrice().multiply(BigDecimal.valueOf(request.getQuantity())));

        Sale updatedSale = saleRepository.save(sale);
        log.info("Sale updated: {}", updatedSale.getSaleId());

        return mapToResponse(updatedSale);
    }

    /**
     * Delete a sale
     */
    @Transactional
    public void deleteSale(Long id) {
        log.info("Deleting sale with ID: {}", id);
        if (!saleRepository.existsById(id)) {
            throw new RuntimeException("Sale not found with ID: " + id);
        }
        saleRepository.deleteById(id);
        log.info("Sale deleted successfully");
    }

    /**
     * Get dashboard statistics
     */
    @Transactional(readOnly = true)
    public DashboardStats getDashboardStats() {
        BigDecimal totalRevenue = saleRepository.getTotalRevenue();
        Long transactionCount = saleRepository.getTransactionCount();
        BigDecimal averageOrderValue = transactionCount > 0
                ? totalRevenue.divide(BigDecimal.valueOf(transactionCount), 2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        // Calculate growth percentages (comparing current month vs previous month)
        LocalDate now = LocalDate.now();
        LocalDate startOfCurrentMonth = now.withDayOfMonth(1);
        LocalDate startOfPreviousMonth = startOfCurrentMonth.minusMonths(1);
        LocalDate endOfPreviousMonth = startOfCurrentMonth.minusDays(1);

        BigDecimal currentMonthRevenue = saleRepository.getTotalRevenueBetweenDates(startOfCurrentMonth, now);
        BigDecimal previousMonthRevenue = saleRepository.getTotalRevenueBetweenDates(startOfPreviousMonth, endOfPreviousMonth);

        BigDecimal revenueGrowth = calculateGrowthPercentage(currentMonthRevenue, previousMonthRevenue);

        Long currentMonthTransactions = saleRepository.countSalesBetweenDates(startOfCurrentMonth, now);
        Long previousMonthTransactions = saleRepository.countSalesBetweenDates(startOfPreviousMonth, endOfPreviousMonth);
        BigDecimal transactionGrowth = calculateGrowthPercentage(
                BigDecimal.valueOf(currentMonthTransactions),
                BigDecimal.valueOf(previousMonthTransactions)
        );

        return DashboardStats.builder()
                .totalRevenue(totalRevenue)
                .transactionCount(transactionCount)
                .averageOrderValue(averageOrderValue)
                .revenueGrowthPercentage(revenueGrowth)
                .transactionGrowthPercentage(transactionGrowth)
                .aovGrowthPercentage(BigDecimal.ZERO) // Simplified for now
                .build();
    }

    /**
     * Calculate growth percentage between two values
     */
    private BigDecimal calculateGrowthPercentage(BigDecimal current, BigDecimal previous) {
        if (previous.compareTo(BigDecimal.ZERO) == 0) {
            return current.compareTo(BigDecimal.ZERO) > 0 ? new BigDecimal("100") : BigDecimal.ZERO;
        }
        return current.subtract(previous)
                .divide(previous, 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100))
                .setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Get revenue data points for chart visualization
     */
    @Transactional(readOnly = true)
    public List<RevenueDataPoint> getRevenueDataPoints() {
        List<Object[]> results = saleRepository.getRevenueByDate();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd");

        return results.stream()
                .map(result -> RevenueDataPoint.builder()
                        .date((LocalDate) result[0])
                        .label(((LocalDate) result[0]).format(formatter))
                        .revenue((BigDecimal) result[1])
                        .transactionCount(((Number) result[2]).intValue())
                        .build())
                .collect(Collectors.toList());
    }

    /**
     * Get revenue by product for distribution chart
     */
    @Transactional(readOnly = true)
    public List<ProductRevenueDto> getRevenueByProduct() {
        List<Object[]> results = saleRepository.getRevenueByProduct();

        return results.stream()
                .map(result -> new ProductRevenueDto(
                        (String) result[0],
                        (BigDecimal) result[1],
                        ((Number) result[2]).intValue()
                ))
                .collect(Collectors.toList());
    }

    /**
     * Get top performing products
     */
    @Transactional(readOnly = true)
    public List<ProductRevenueDto> getTopProducts(int limit) {
        List<Object[]> results = saleRepository.getTopProductsByRevenue(PageRequest.of(0, limit));

        return results.stream()
                .map(result -> new ProductRevenueDto(
                        (String) result[0],
                        (BigDecimal) result[1],
                        0
                ))
                .collect(Collectors.toList());
    }

    /**
     * Search sales by product name
     */
    @Transactional(readOnly = true)
    public List<SaleResponse> searchSales(String productName) {
        return saleRepository.findByProductNameContainingIgnoreCase(productName)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /**
     * DTO for product revenue data
     */
    public record ProductRevenueDto(String productName, BigDecimal revenue, Integer quantity) {}
}
