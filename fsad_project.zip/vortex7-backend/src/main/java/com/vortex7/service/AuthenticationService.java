package com.vortex7.service;

import com.vortex7.dto.LoginRequest;
import com.vortex7.dto.LoginResponse;
import com.vortex7.validation.EmailValidator;
import com.vortex7.validation.EmailValidator.ValidationResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * AuthenticationService - Handles authentication logic including email validation
 * Provides secure login processing with strict Gmail validation
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthenticationService {

    private final EmailValidator emailValidator;

    /**
     * Process login request with strict Gmail validation
     * 
     * @param request The login request containing email and password
     * @return LoginResponse with authentication result
     */
    public LoginResponse login(LoginRequest request) {
        String email = request.getEmail();
        String password = request.getPassword();
        
        log.info("Processing login request for email: {}", maskEmail(email));
        
        // Validate Gmail address
        ValidationResult validationResult = emailValidator.validateGmail(email);
        
        if (!validationResult.valid()) {
            log.warn("Login failed - Email validation failed: {}", validationResult.message());
            return LoginResponse.builder()
                    .success(false)
                    .message(validationResult.message())
                    .timestamp(LocalDateTime.now())
                    .build();
        }
        
        // Validate password (basic check - in production, verify against database)
        if (password == null || password.length() < 6) {
            log.warn("Login failed - Invalid password for email: {}", maskEmail(email));
            return LoginResponse.builder()
                    .success(false)
                    .message("Invalid password")
                    .timestamp(LocalDateTime.now())
                    .build();
        }
        
        // In a real application, you would:
        // 1. Check if user exists in database
        // 2. Verify password hash
        // 3. Generate JWT token
        // 4. Return user details
        
        log.info("Login validation passed for email: {}", maskEmail(email));
        
        // Return success response (indicating next step is OTP)
        return LoginResponse.builder()
                .success(true)
                .message("Credentials validated successfully")
                .email(email)
                .userName(extractUserName(email))
                .nextStep("OTP_REQUIRED")
                .timestamp(LocalDateTime.now())
                .build();
    }
    
    /**
     * Validate email only (for frontend pre-validation)
     * 
     * @param email The email to validate
     * @return ValidationResult with validation status
     */
    public ValidationResult validateEmail(String email) {
        return emailValidator.validateGmail(email);
    }
    
    /**
     * Check if email is a valid Gmail address (quick check)
     * 
     * @param email The email to check
     * @return true if valid Gmail
     */
    public boolean isValidGmail(String email) {
        return emailValidator.validateGmail(email).valid();
    }
    
    /**
     * Mask email for logging (privacy protection)
     * e.g., john.doe@gmail.com -> j***@gmail.com
     */
    private String maskEmail(String email) {
        if (email == null || !email.contains("@")) {
            return "***";
        }
        String localPart = email.substring(0, email.indexOf('@'));
        String domain = email.substring(email.indexOf('@'));
        
        if (localPart.length() <= 2) {
            return "***" + domain;
        }
        
        return localPart.charAt(0) + "***" + domain;
    }
    
    /**
     * Extract user name from email for display
     * e.g., john.doe@gmail.com -> John Doe
     */
    private String extractUserName(String email) {
        if (email == null || !email.contains("@")) {
            return "User";
        }
        
        String localPart = email.substring(0, email.indexOf('@'));
        
        // Replace dots and underscores with spaces
        String name = localPart.replace(".", " ").replace("_", " ");
        
        // Capitalize each word
        String[] words = name.split("\\s+");
        StringBuilder result = new StringBuilder();
        
        for (String word : words) {
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        
        return result.toString().trim();
    }
}
