package com.vortex7.validation;

import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * EmailValidator - Utility class for validating Gmail addresses
 * Provides strict validation to ensure only real Gmail addresses are accepted
 */
@Component
public class EmailValidator {

    // Regex for valid Gmail local part characters (letters, numbers, dots, underscores)
    private static final Pattern VALID_CHARS_PATTERN = Pattern.compile("^[a-z0-9._]+$");
    
    // Regex for detecting test/dummy email patterns
    private static final Pattern TEST_PATTERN = Pattern.compile("^(test|dummy|abc|xyz|temp|fake|sample|demo|user|admin|info)[0-9]*$");
    
    // Set of blocked dummy email addresses
    private static final Set<String> BLOCKED_EMAILS = new HashSet<>(Arrays.asList(
            "test@gmail.com",
            "dummy@gmail.com",
            "abc@gmail.com",
            "example@gmail.com",
            "user@gmail.com",
            "admin@gmail.com",
            "info@gmail.com",
            "email@gmail.com",
            "sample@gmail.com",
            "demo@gmail.com",
            "temp@gmail.com",
            "fake@gmail.com",
            "xyz@gmail.com"
    ));
    
    // Gmail domain suffix
    private static final String GMAIL_DOMAIN = "@gmail.com";
    
    // Minimum length for local part (before @)
    private static final int MIN_LOCAL_PART_LENGTH = 5;
    
    // Maximum length for local part
    private static final int MAX_LOCAL_PART_LENGTH = 30;

    /**
     * Validation result containing status and error message
     */
    public record ValidationResult(boolean valid, String message) {
        public static ValidationResult success() {
            return new ValidationResult(true, null);
        }
        
        public static ValidationResult error(String message) {
            return new ValidationResult(false, message);
        }
    }

    /**
     * Validate a Gmail email address with strict rules
     * 
     * Validation rules:
     * 1. Must end with @gmail.com
     * 2. Must have at least 5 characters before @
     * 3. Must contain only valid characters (letters, numbers, dots, underscores)
     * 4. Must not be in blocked list
     * 5. Must not have consecutive dots
     * 6. Must not start or end with a dot
     * 7. Must not match common test patterns
     * 
     * @param email The email address to validate
     * @return ValidationResult containing validation status and error message
     */
    public ValidationResult validateGmail(String email) {
        // Check if null or empty
        if (email == null || email.trim().isEmpty()) {
            return ValidationResult.error("Email is required");
        }
        
        // Normalize email
        email = email.trim().toLowerCase();
        
        // Check if ends with @gmail.com
        if (!email.endsWith(GMAIL_DOMAIN)) {
            return ValidationResult.error("Please enter a valid Gmail address");
        }
        
        // Extract local part (before @)
        String localPart = email.substring(0, email.indexOf('@'));
        
        // Check minimum length
        if (localPart.length() < MIN_LOCAL_PART_LENGTH) {
            return ValidationResult.error("Email must have at least 5 characters before @gmail.com");
        }
        
        // Check maximum length
        if (localPart.length() > MAX_LOCAL_PART_LENGTH) {
            return ValidationResult.error("Email is too long");
        }
        
        // Check valid characters
        if (!VALID_CHARS_PATTERN.matcher(localPart).matches()) {
            return ValidationResult.error("Email contains invalid characters");
        }
        
        // Check no consecutive dots
        if (localPart.contains("..")) {
            return ValidationResult.error("Email cannot contain consecutive dots");
        }
        
        // Check doesn't start or end with dot
        if (localPart.startsWith(".") || localPart.endsWith(".")) {
            return ValidationResult.error("Email cannot start or end with a dot");
        }
        
        // Check against blocked emails
        if (BLOCKED_EMAILS.contains(email)) {
            return ValidationResult.error("Please use a real Gmail address");
        }
        
        // Check for test patterns
        if (TEST_PATTERN.matcher(localPart).matches()) {
            return ValidationResult.error("Please use a real Gmail address");
        }
        
        return ValidationResult.success();
    }
    
    /**
     * Quick check if email is a Gmail address
     * @param email The email to check
     * @return true if it's a Gmail address
     */
    public boolean isGmailAddress(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return email.trim().toLowerCase().endsWith(GMAIL_DOMAIN);
    }
    
    /**
     * Check if email is in the blocked list
     * @param email The email to check
     * @return true if email is blocked
     */
    public boolean isBlockedEmail(String email) {
        if (email == null) {
            return false;
        }
        return BLOCKED_EMAILS.contains(email.trim().toLowerCase());
    }
}
